public interface TwoSideLinkedList extends LinkedList{
    void addLast(int value);

    void addFirst(int value);
}
